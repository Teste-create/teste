import { useQuery, useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { useState, useEffect } from "react";
import { toast } from "sonner";
import { FinancialSummary } from "./FinancialSummary";
import { TransactionsList } from "./TransactionsList";
import { AddTransactionModal } from "./AddTransactionModal";
import { GoalsSection } from "./GoalsSection";
import { AlertsPanel } from "./AlertsPanel";
import { WhatsAppSetup } from "./WhatsAppSetup";

export function Dashboard() {
  const [activeTab, setActiveTab] = useState<"overview" | "transactions" | "goals" | "whatsapp" | "settings">("overview");
  const [showAddTransaction, setShowAddTransaction] = useState(false);
  
  const userProfile = useQuery(api.users.getCurrentUserProfile);
  const userStats = useQuery(api.users.getUserStats);
  const initializeCategories = useMutation(api.categories.initializeDefaultCategories);

  // Initialize default categories on first load
  useEffect(() => {
    const initCategories = async () => {
      try {
        await initializeCategories();
      } catch (error) {
        // Categories might already exist, ignore error
      }
    };
    initCategories();
  }, [initializeCategories]);

  if (!userProfile) {
    return (
      <div className="flex justify-center items-center min-h-[60vh]">
        <div className="animate-spin rounded-full h-12 w-12 border-4 border-orange-200 border-t-orange-600"></div>
      </div>
    );
  }

  const { user, profile } = userProfile;

  return (
    <div className="space-y-6">
      {/* Header com boas-vindas */}
      <div className="bg-white rounded-xl p-6 shadow-sm border border-orange-100">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-4 sm:space-y-0">
          <div>
            <h2 className="text-2xl font-bold text-gray-900">
              Olá, {profile?.firstName || user?.name || "Usuário"}! 👋
            </h2>
            <p className="text-gray-600">
              {profile?.subscriptionStatus === "free" 
                ? "Plano Gratuito - Upgrade para mais funcionalidades"
                : `Plano ${profile?.subscriptionStatus?.toUpperCase()} ativo`
              }
            </p>
          </div>
          <div className="flex items-center space-x-3">
            <button
              onClick={() => setShowAddTransaction(true)}
              className="bg-gradient-to-r from-orange-500 to-orange-600 text-white px-4 py-2 rounded-lg font-medium hover:from-orange-600 hover:to-orange-700 transition-all duration-200 shadow-sm hover:shadow-md"
            >
              + Nova Transação
            </button>
          </div>
        </div>
      </div>

      {/* Navegação por abas */}
      <div className="bg-white rounded-xl shadow-sm border border-orange-100 overflow-hidden">
        <div className="border-b border-gray-200">
          <nav className="flex space-x-8 px-6">
            {[
              { id: "overview", label: "Visão Geral", icon: "📊" },
              { id: "transactions", label: "Transações", icon: "💳" },
              { id: "goals", label: "Metas", icon: "🎯" },
              { id: "whatsapp", label: "WhatsApp", icon: "📱" },
              { id: "settings", label: "Configurações", icon: "⚙️" },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center space-x-2 py-4 px-2 border-b-2 font-medium text-sm transition-colors ${
                  activeTab === tab.id
                    ? "border-orange-500 text-orange-600"
                    : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
                }`}
              >
                <span>{tab.icon}</span>
                <span>{tab.label}</span>
              </button>
            ))}
          </nav>
        </div>

        <div className="p-6">
          {activeTab === "overview" && (
            <div className="space-y-6">
              <FinancialSummary stats={userStats} />
              <div className="grid lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2">
                  <TransactionsList limit={5} showHeader={true} />
                </div>
                <div>
                  <AlertsPanel />
                </div>
              </div>
            </div>
          )}

          {activeTab === "transactions" && (
            <TransactionsList showHeader={false} />
          )}

          {activeTab === "goals" && (
            <GoalsSection />
          )}

          {activeTab === "whatsapp" && (
            <WhatsAppSetup profile={profile} />
          )}

          {activeTab === "settings" && (
            <div className="space-y-6">
              <h3 className="text-lg font-semibold text-gray-900">Configurações</h3>
              <div className="bg-orange-50 border border-orange-200 rounded-lg p-4">
                <p className="text-orange-800">
                  🚧 Seção em desenvolvimento. Em breve você poderá configurar preferências, exportar dados e gerenciar sua conta.
                </p>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Modal de adicionar transação */}
      {showAddTransaction && (
        <AddTransactionModal
          onClose={() => setShowAddTransaction(false)}
          onSuccess={() => {
            setShowAddTransaction(false);
            toast.success("Transação adicionada com sucesso!");
          }}
        />
      )}
    </div>
  );
}
