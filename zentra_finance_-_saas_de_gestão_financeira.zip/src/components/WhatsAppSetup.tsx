import { useState } from "react";
import { useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { toast } from "sonner";

interface WhatsAppSetupProps {
  profile: {
    whatsappConnected: boolean;
    whatsappNumber?: string;
  } | null;
}

export function WhatsAppSetup({ profile }: WhatsAppSetupProps) {
  const [phoneNumber, setPhoneNumber] = useState("");
  const [isConnecting, setIsConnecting] = useState(false);
  
  const connectWhatsApp = useMutation(api.users.connectWhatsApp);

  const handleConnect = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!phoneNumber.trim()) {
      toast.error("Digite seu número do WhatsApp");
      return;
    }

    // Validar formato do número (básico)
    const cleanNumber = phoneNumber.replace(/\D/g, "");
    if (cleanNumber.length < 10 || cleanNumber.length > 15) {
      toast.error("Número de telefone inválido");
      return;
    }

    setIsConnecting(true);
    try {
      await connectWhatsApp({ whatsappNumber: cleanNumber });
      toast.success("WhatsApp conectado com sucesso!");
      setPhoneNumber("");
    } catch (error) {
      toast.error("Erro ao conectar WhatsApp");
      console.error(error);
    } finally {
      setIsConnecting(false);
    }
  };

  const formatPhoneNumber = (value: string) => {
    const numbers = value.replace(/\D/g, "");
    if (numbers.length <= 11) {
      return numbers.replace(/(\d{2})(\d{5})(\d{4})/, "($1) $2-$3");
    }
    return numbers.replace(/(\d{2})(\d{2})(\d{5})(\d{4})/, "+$1 ($2) $3-$4");
  };

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-semibold text-gray-900 mb-2">Integração WhatsApp</h3>
        <p className="text-gray-600">
          Conecte seu WhatsApp para registrar transações automaticamente enviando mensagens de texto ou áudio.
        </p>
      </div>

      {profile?.whatsappConnected ? (
        <div className="bg-green-50 border border-green-200 rounded-lg p-6">
          <div className="flex items-center space-x-3 mb-4">
            <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
              <span className="text-2xl">✅</span>
            </div>
            <div>
              <h4 className="font-semibold text-green-900">WhatsApp Conectado</h4>
              <p className="text-sm text-green-700">
                Número: {profile.whatsappNumber ? formatPhoneNumber(profile.whatsappNumber) : "Não informado"}
              </p>
            </div>
          </div>

          <div className="space-y-4">
            <div className="bg-white rounded-lg p-4 border border-green-200">
              <h5 className="font-medium text-gray-900 mb-2">Como usar:</h5>
              <ul className="text-sm text-gray-700 space-y-1">
                <li>• Envie mensagens como: "Gastei 25 reais no almoço"</li>
                <li>• Ou áudios descrevendo suas transações</li>
                <li>• A IA processará automaticamente e criará a transação</li>
                <li>• Você receberá confirmações das transações criadas</li>
              </ul>
            </div>

            <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
              <div className="flex items-start space-x-2">
                <span className="text-yellow-600 text-lg">⚠️</span>
                <div>
                  <p className="text-sm text-yellow-800 font-medium">Funcionalidade em desenvolvimento</p>
                  <p className="text-xs text-yellow-700 mt-1">
                    A integração com WhatsApp está sendo finalizada. Em breve você poderá usar esta funcionalidade.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      ) : (
        <div className="space-y-6">
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
            <div className="flex items-center space-x-3 mb-4">
              <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                <span className="text-2xl">📱</span>
              </div>
              <div>
                <h4 className="font-semibold text-blue-900">Conectar WhatsApp</h4>
                <p className="text-sm text-blue-700">
                  Registre transações enviando mensagens ou áudios
                </p>
              </div>
            </div>

            <form onSubmit={handleConnect} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Número do WhatsApp
                </label>
                <input
                  type="tel"
                  value={phoneNumber}
                  onChange={(e) => setPhoneNumber(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500"
                  placeholder="(11) 99999-9999"
                  disabled={isConnecting}
                />
                <p className="text-xs text-gray-500 mt-1">
                  Digite seu número com DDD (ex: 11999999999)
                </p>
              </div>

              <button
                type="submit"
                disabled={isConnecting}
                className="w-full bg-gradient-to-r from-green-500 to-green-600 text-white px-4 py-2 rounded-lg font-medium hover:from-green-600 hover:to-green-700 transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isConnecting ? "Conectando..." : "Conectar WhatsApp"}
              </button>
            </form>
          </div>

          <div className="bg-orange-50 border border-orange-200 rounded-lg p-4">
            <div className="flex items-start space-x-2">
              <span className="text-orange-600 text-lg">🚧</span>
              <div>
                <p className="text-sm text-orange-800 font-medium">Funcionalidade em desenvolvimento</p>
                <p className="text-xs text-orange-700 mt-1">
                  A integração com WhatsApp Business API está sendo implementada. 
                  Por enquanto, você pode conectar seu número para futuro uso.
                </p>
              </div>
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-4">
            <div className="bg-white border border-gray-200 rounded-lg p-4">
              <h5 className="font-medium text-gray-900 mb-2">📝 Mensagens de Texto</h5>
              <p className="text-sm text-gray-600">
                Envie mensagens como "Gastei 50 reais no supermercado" e a IA criará a transação automaticamente.
              </p>
            </div>

            <div className="bg-white border border-gray-200 rounded-lg p-4">
              <h5 className="font-medium text-gray-900 mb-2">🎤 Mensagens de Áudio</h5>
              <p className="text-sm text-gray-600">
                Grave áudios descrevendo suas transações e deixe a IA transcrever e processar.
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
