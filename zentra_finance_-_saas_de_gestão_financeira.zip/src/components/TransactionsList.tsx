import { useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";
import { useState } from "react";

interface TransactionsListProps {
  limit?: number;
  showHeader?: boolean;
}

export function TransactionsList({ limit, showHeader = true }: TransactionsListProps) {
  const [filter, setFilter] = useState<"all" | "expense" | "income" | "investment">("all");
  
  const transactions = useQuery(api.transactions.getUserTransactions, {
    limit: limit || 50,
    type: filter === "all" ? undefined : filter,
  });

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value);
  };

  const formatDate = (timestamp: number) => {
    return new Date(timestamp).toLocaleDateString('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
    });
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case "income":
        return "text-green-600 bg-green-50 border-green-200";
      case "expense":
        return "text-red-600 bg-red-50 border-red-200";
      case "investment":
        return "text-blue-600 bg-blue-50 border-blue-200";
      default:
        return "text-gray-600 bg-gray-50 border-gray-200";
    }
  };

  const getTypeLabel = (type: string) => {
    switch (type) {
      case "income":
        return "Receita";
      case "expense":
        return "Despesa";
      case "investment":
        return "Investimento";
      default:
        return type;
    }
  };

  if (!transactions) {
    return (
      <div className="space-y-4">
        {showHeader && <h3 className="text-lg font-semibold text-gray-900">Transações Recentes</h3>}
        <div className="space-y-3">
          {[1, 2, 3].map((i) => (
            <div key={i} className="bg-gray-100 rounded-lg p-4 animate-pulse">
              <div className="flex justify-between items-center">
                <div className="space-y-2">
                  <div className="h-4 bg-gray-200 rounded w-32"></div>
                  <div className="h-3 bg-gray-200 rounded w-24"></div>
                </div>
                <div className="h-6 bg-gray-200 rounded w-20"></div>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {showHeader && (
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-4 sm:space-y-0">
          <h3 className="text-lg font-semibold text-gray-900">
            {limit ? "Transações Recentes" : "Todas as Transações"}
          </h3>
          
          {!limit && (
            <div className="flex space-x-2">
              {[
                { value: "all", label: "Todas" },
                { value: "income", label: "Receitas" },
                { value: "expense", label: "Despesas" },
                { value: "investment", label: "Investimentos" },
              ].map((option) => (
                <button
                  key={option.value}
                  onClick={() => setFilter(option.value as any)}
                  className={`px-3 py-1 rounded-full text-sm font-medium transition-colors ${
                    filter === option.value
                      ? "bg-orange-100 text-orange-700 border border-orange-300"
                      : "bg-gray-100 text-gray-600 hover:bg-gray-200"
                  }`}
                >
                  {option.label}
                </button>
              ))}
            </div>
          )}
        </div>
      )}

      {transactions.length === 0 ? (
        <div className="text-center py-12">
          <span className="text-6xl mb-4 block">📊</span>
          <h3 className="text-lg font-medium text-gray-900 mb-2">Nenhuma transação encontrada</h3>
          <p className="text-gray-600">
            {filter === "all" 
              ? "Comece adicionando sua primeira transação ou conecte seu WhatsApp."
              : `Nenhuma ${getTypeLabel(filter).toLowerCase()} encontrada.`
            }
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          {transactions.map((transaction) => (
            <div
              key={transaction._id}
              className="bg-white border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <div className="flex-shrink-0">
                    <span className="text-2xl">{transaction.category?.icon || "📦"}</span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center space-x-2">
                      <p className="text-sm font-medium text-gray-900 truncate">
                        {transaction.description}
                      </p>
                      <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium border ${getTypeColor(transaction.type)}`}>
                        {getTypeLabel(transaction.type)}
                      </span>
                    </div>
                    <div className="flex items-center space-x-4 mt-1">
                      <p className="text-sm text-gray-500">
                        {transaction.category?.name || "Sem categoria"}
                      </p>
                      <p className="text-sm text-gray-500">
                        {formatDate(transaction.date)}
                      </p>
                      {transaction.source === "whatsapp" && (
                        <span className="inline-flex items-center text-xs text-green-600">
                          📱 WhatsApp
                        </span>
                      )}
                    </div>
                  </div>
                </div>
                <div className="flex-shrink-0">
                  <p className={`text-lg font-semibold ${
                    transaction.type === "income" 
                      ? "text-green-600" 
                      : transaction.type === "expense"
                      ? "text-red-600"
                      : "text-blue-600"
                  }`}>
                    {transaction.type === "income" ? "+" : "-"}{formatCurrency(transaction.amount)}
                  </p>
                </div>
              </div>
            </div>
          ))}
          
          {limit && transactions.length >= limit && (
            <div className="text-center pt-4">
              <button className="text-orange-600 hover:text-orange-700 font-medium text-sm">
                Ver todas as transações →
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
