import { useQuery, useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { toast } from "sonner";

export function AlertsPanel() {
  const alerts = useQuery(api.alerts.getUserAlerts, { limit: 5 });
  const markAsRead = useMutation(api.alerts.markAlertAsRead);
  const markAllAsRead = useMutation(api.alerts.markAllAlertsAsRead);

  const handleMarkAsRead = async (alertId: string) => {
    try {
      await markAsRead({ alertId: alertId as any });
    } catch (error) {
      toast.error("Erro ao marcar alerta como lido");
    }
  };

  const handleMarkAllAsRead = async () => {
    try {
      await markAllAsRead();
      toast.success("Todos os alertas foram marcados como lidos");
    } catch (error) {
      toast.error("Erro ao marcar alertas como lidos");
    }
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case "critical":
        return "border-red-200 bg-red-50 text-red-800";
      case "warning":
        return "border-yellow-200 bg-yellow-50 text-yellow-800";
      case "info":
        return "border-blue-200 bg-blue-50 text-blue-800";
      default:
        return "border-gray-200 bg-gray-50 text-gray-800";
    }
  };

  const getSeverityIcon = (severity: string) => {
    switch (severity) {
      case "critical":
        return "🚨";
      case "warning":
        return "⚠️";
      case "info":
        return "ℹ️";
      default:
        return "📢";
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case "budget_limit":
        return "💰";
      case "goal_progress":
        return "🎯";
      case "recurring_reminder":
        return "🔔";
      case "unusual_spending":
        return "📊";
      default:
        return "📢";
    }
  };

  if (!alerts) {
    return (
      <div className="space-y-4">
        <h3 className="text-lg font-semibold text-gray-900">Alertas</h3>
        <div className="space-y-3">
          {[1, 2, 3].map((i) => (
            <div key={i} className="bg-gray-100 rounded-lg p-4 animate-pulse">
              <div className="space-y-2">
                <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                <div className="h-3 bg-gray-200 rounded w-1/2"></div>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  const unreadCount = alerts.filter(alert => !alert.isRead).length;

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <h3 className="text-lg font-semibold text-gray-900">Alertas</h3>
          {unreadCount > 0 && (
            <span className="bg-red-100 text-red-800 text-xs font-medium px-2 py-1 rounded-full">
              {unreadCount}
            </span>
          )}
        </div>
        {unreadCount > 0 && (
          <button
            onClick={handleMarkAllAsRead}
            className="text-xs text-orange-600 hover:text-orange-700 font-medium"
          >
            Marcar todos como lidos
          </button>
        )}
      </div>

      {alerts.length === 0 ? (
        <div className="text-center py-8">
          <span className="text-4xl mb-2 block">🔔</span>
          <p className="text-gray-600 text-sm">Nenhum alerta no momento</p>
        </div>
      ) : (
        <div className="space-y-3">
          {alerts.map((alert) => (
            <div
              key={alert._id}
              className={`border rounded-lg p-4 transition-all duration-200 hover:shadow-sm cursor-pointer ${
                alert.isRead 
                  ? "border-gray-200 bg-gray-50" 
                  : getSeverityColor(alert.severity)
              }`}
              onClick={() => !alert.isRead && handleMarkAsRead(alert._id)}
            >
              <div className="flex items-start space-x-3">
                <div className="flex-shrink-0 flex items-center space-x-1">
                  <span className="text-lg">{getTypeIcon(alert.type)}</span>
                  <span className="text-sm">{getSeverityIcon(alert.severity)}</span>
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <h4 className={`text-sm font-medium ${
                      alert.isRead ? "text-gray-600" : "text-gray-900"
                    }`}>
                      {alert.title}
                    </h4>
                    {!alert.isRead && (
                      <div className="w-2 h-2 bg-orange-500 rounded-full flex-shrink-0"></div>
                    )}
                  </div>
                  <p className={`text-xs mt-1 ${
                    alert.isRead ? "text-gray-500" : "text-gray-700"
                  }`}>
                    {alert.message}
                  </p>
                  <p className="text-xs text-gray-400 mt-2">
                    {new Date(alert._creationTime).toLocaleDateString('pt-BR', {
                      day: '2-digit',
                      month: '2-digit',
                      hour: '2-digit',
                      minute: '2-digit'
                    })}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
