interface FinancialSummaryProps {
  stats: {
    monthly: {
      expenses: number;
      income: number;
      investments: number;
      balance: number;
      transactionCount: number;
    };
    weekly: {
      expenses: number;
      transactionCount: number;
    };
  } | null | undefined;
}

export function FinancialSummary({ stats }: FinancialSummaryProps) {
  if (!stats) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {[1, 2, 3, 4].map((i) => (
          <div key={i} className="bg-gray-100 rounded-lg p-6 animate-pulse">
            <div className="h-4 bg-gray-200 rounded mb-2"></div>
            <div className="h-8 bg-gray-200 rounded"></div>
          </div>
        ))}
      </div>
    );
  }

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value);
  };

  const cards = [
    {
      title: "Receitas do Mês",
      value: formatCurrency(stats.monthly.income),
      icon: "💰",
      color: "text-green-600",
      bgColor: "bg-green-50",
      borderColor: "border-green-200",
    },
    {
      title: "Despesas do Mês",
      value: formatCurrency(stats.monthly.expenses),
      icon: "💸",
      color: "text-red-600",
      bgColor: "bg-red-50",
      borderColor: "border-red-200",
    },
    {
      title: "Investimentos",
      value: formatCurrency(stats.monthly.investments),
      icon: "📈",
      color: "text-blue-600",
      bgColor: "bg-blue-50",
      borderColor: "border-blue-200",
    },
    {
      title: "Saldo do Mês",
      value: formatCurrency(stats.monthly.balance),
      icon: stats.monthly.balance >= 0 ? "✅" : "⚠️",
      color: stats.monthly.balance >= 0 ? "text-green-600" : "text-red-600",
      bgColor: stats.monthly.balance >= 0 ? "bg-green-50" : "bg-red-50",
      borderColor: stats.monthly.balance >= 0 ? "border-green-200" : "border-red-200",
    },
  ];

  return (
    <div className="space-y-4">
      <h3 className="text-lg font-semibold text-gray-900">Resumo Financeiro</h3>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {cards.map((card, index) => (
          <div
            key={index}
            className={`${card.bgColor} ${card.borderColor} border rounded-lg p-6 transition-all duration-200 hover:shadow-md`}
          >
            <div className="flex items-center justify-between mb-2">
              <span className="text-2xl">{card.icon}</span>
              <div className={`text-xs px-2 py-1 rounded-full bg-white/50 ${card.color}`}>
                Este mês
              </div>
            </div>
            <div className="space-y-1">
              <p className="text-sm font-medium text-gray-600">{card.title}</p>
              <p className={`text-2xl font-bold ${card.color}`}>{card.value}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Estatísticas adicionais */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-6">
        <div className="bg-orange-50 border border-orange-200 rounded-lg p-4">
          <div className="flex items-center space-x-3">
            <span className="text-2xl">📊</span>
            <div>
              <p className="text-sm font-medium text-orange-800">Transações este mês</p>
              <p className="text-xl font-bold text-orange-600">{stats.monthly.transactionCount}</p>
            </div>
          </div>
        </div>

        <div className="bg-purple-50 border border-purple-200 rounded-lg p-4">
          <div className="flex items-center space-x-3">
            <span className="text-2xl">📅</span>
            <div>
              <p className="text-sm font-medium text-purple-800">Gastos esta semana</p>
              <p className="text-xl font-bold text-purple-600">{formatCurrency(stats.weekly.expenses)}</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
