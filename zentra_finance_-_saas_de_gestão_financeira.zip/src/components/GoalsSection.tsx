import { useQuery, useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { useState } from "react";
import { toast } from "sonner";

export function GoalsSection() {
  const [showAddGoal, setShowAddGoal] = useState(false);
  const goals = useQuery(api.goals.getUserGoals, {});

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value);
  };

  const formatDate = (timestamp: number) => {
    return new Date(timestamp).toLocaleDateString('pt-BR');
  };

  const getProgressPercentage = (current: number, target: number) => {
    return Math.min((current / target) * 100, 100);
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case "savings": return "💰";
      case "expense_limit": return "🎯";
      case "investment": return "📈";
      case "debt_payoff": return "💳";
      default: return "🎯";
    }
  };

  const getCategoryLabel = (category: string) => {
    switch (category) {
      case "savings": return "Poupança";
      case "expense_limit": return "Limite de Gastos";
      case "investment": return "Investimento";
      case "debt_payoff": return "Pagamento de Dívida";
      default: return category;
    }
  };

  if (!goals) {
    return (
      <div className="space-y-4">
        <div className="flex justify-between items-center">
          <h3 className="text-lg font-semibold text-gray-900">Metas Financeiras</h3>
          <div className="h-8 w-24 bg-gray-200 rounded animate-pulse"></div>
        </div>
        <div className="grid gap-4">
          {[1, 2].map((i) => (
            <div key={i} className="bg-gray-100 rounded-lg p-6 animate-pulse">
              <div className="space-y-3">
                <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                <div className="h-3 bg-gray-200 rounded w-1/2"></div>
                <div className="h-2 bg-gray-200 rounded"></div>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-semibold text-gray-900">Metas Financeiras</h3>
        <button
          onClick={() => setShowAddGoal(true)}
          className="bg-gradient-to-r from-orange-500 to-orange-600 text-white px-4 py-2 rounded-lg font-medium hover:from-orange-600 hover:to-orange-700 transition-all duration-200 shadow-sm hover:shadow-md text-sm"
        >
          + Nova Meta
        </button>
      </div>

      {goals.length === 0 ? (
        <div className="text-center py-12">
          <span className="text-6xl mb-4 block">🎯</span>
          <h3 className="text-lg font-medium text-gray-900 mb-2">Nenhuma meta definida</h3>
          <p className="text-gray-600 mb-4">
            Defina metas financeiras para acompanhar seu progresso e alcançar seus objetivos.
          </p>
          <button
            onClick={() => setShowAddGoal(true)}
            className="bg-gradient-to-r from-orange-500 to-orange-600 text-white px-6 py-2 rounded-lg font-medium hover:from-orange-600 hover:to-orange-700 transition-all duration-200"
          >
            Criar primeira meta
          </button>
        </div>
      ) : (
        <div className="grid gap-4">
          {goals.map((goal) => {
            const progress = getProgressPercentage(goal.currentAmount, goal.targetAmount);
            const isCompleted = goal.status === "completed";
            const isOverdue = new Date(goal.targetDate) < new Date() && !isCompleted;

            return (
              <div
                key={goal._id}
                className={`bg-white border rounded-lg p-6 transition-all duration-200 hover:shadow-md ${
                  isCompleted 
                    ? "border-green-200 bg-green-50" 
                    : isOverdue 
                    ? "border-red-200 bg-red-50"
                    : "border-gray-200"
                }`}
              >
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center space-x-3">
                    <span className="text-2xl">{getCategoryIcon(goal.category)}</span>
                    <div>
                      <h4 className="font-semibold text-gray-900">{goal.title}</h4>
                      <p className="text-sm text-gray-600">{getCategoryLabel(goal.category)}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${
                      isCompleted 
                        ? "bg-green-100 text-green-800"
                        : goal.status === "paused"
                        ? "bg-yellow-100 text-yellow-800"
                        : isOverdue
                        ? "bg-red-100 text-red-800"
                        : "bg-blue-100 text-blue-800"
                    }`}>
                      {isCompleted ? "✅ Concluída" : 
                       goal.status === "paused" ? "⏸️ Pausada" :
                       isOverdue ? "⚠️ Atrasada" : "🔄 Ativa"}
                    </div>
                  </div>
                </div>

                {goal.description && (
                  <p className="text-sm text-gray-600 mb-4">{goal.description}</p>
                )}

                <div className="space-y-3">
                  <div className="flex justify-between items-center text-sm">
                    <span className="text-gray-600">Progresso</span>
                    <span className="font-medium">
                      {formatCurrency(goal.currentAmount)} / {formatCurrency(goal.targetAmount)}
                    </span>
                  </div>

                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div
                      className={`h-2 rounded-full transition-all duration-300 ${
                        isCompleted 
                          ? "bg-green-500" 
                          : progress >= 80 
                          ? "bg-orange-500" 
                          : "bg-blue-500"
                      }`}
                      style={{ width: `${progress}%` }}
                    ></div>
                  </div>

                  <div className="flex justify-between items-center text-sm text-gray-600">
                    <span>{progress.toFixed(1)}% concluído</span>
                    <span>Meta: {formatDate(goal.targetDate)}</span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {showAddGoal && (
        <AddGoalModal
          onClose={() => setShowAddGoal(false)}
          onSuccess={() => {
            setShowAddGoal(false);
            toast.success("Meta criada com sucesso!");
          }}
        />
      )}
    </div>
  );
}

interface AddGoalModalProps {
  onClose: () => void;
  onSuccess: () => void;
}

function AddGoalModal({ onClose, onSuccess }: AddGoalModalProps) {
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    targetAmount: "",
    targetDate: "",
    category: "savings" as "savings" | "expense_limit" | "investment" | "debt_payoff",
  });

  const createGoal = useMutation(api.goals.createGoal);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.title || !formData.targetAmount || !formData.targetDate) {
      toast.error("Preencha todos os campos obrigatórios");
      return;
    }

    try {
      await createGoal({
        title: formData.title,
        description: formData.description || undefined,
        targetAmount: parseFloat(formData.targetAmount),
        targetDate: new Date(formData.targetDate).getTime(),
        category: formData.category,
      });
      
      onSuccess();
    } catch (error) {
      toast.error("Erro ao criar meta");
      console.error(error);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-xl max-w-md w-full p-6 space-y-6">
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-semibold text-gray-900">Nova Meta</h2>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600 text-2xl"
          >
            ×
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Categoria */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Tipo de Meta
            </label>
            <div className="grid grid-cols-2 gap-2">
              {[
                { value: "savings", label: "Poupança", icon: "💰" },
                { value: "expense_limit", label: "Limite Gastos", icon: "🎯" },
                { value: "investment", label: "Investimento", icon: "📈" },
                { value: "debt_payoff", label: "Pagar Dívida", icon: "💳" },
              ].map((type) => (
                <button
                  key={type.value}
                  type="button"
                  onClick={() => setFormData({ ...formData, category: type.value as any })}
                  className={`p-3 border-2 rounded-lg text-center transition-all ${
                    formData.category === type.value
                      ? "border-orange-300 text-orange-700 bg-orange-50"
                      : "border-gray-200 text-gray-600 hover:border-gray-300"
                  }`}
                >
                  <div className="text-lg mb-1">{type.icon}</div>
                  <div className="text-xs font-medium">{type.label}</div>
                </button>
              ))}
            </div>
          </div>

          {/* Título */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Título da Meta *
            </label>
            <input
              type="text"
              value={formData.title}
              onChange={(e) => setFormData({ ...formData, title: e.target.value })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500"
              placeholder="Ex: Reserva de emergência"
              required
            />
          </div>

          {/* Descrição */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Descrição (opcional)
            </label>
            <textarea
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500"
              placeholder="Descreva sua meta..."
              rows={2}
            />
          </div>

          {/* Valor alvo */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Valor Alvo (R$) *
            </label>
            <input
              type="number"
              step="0.01"
              min="0"
              value={formData.targetAmount}
              onChange={(e) => setFormData({ ...formData, targetAmount: e.target.value })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500"
              placeholder="0,00"
              required
            />
          </div>

          {/* Data alvo */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Data Alvo *
            </label>
            <input
              type="date"
              value={formData.targetDate}
              onChange={(e) => setFormData({ ...formData, targetDate: e.target.value })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500"
              min={new Date().toISOString().split('T')[0]}
              required
            />
          </div>

          {/* Botões */}
          <div className="flex space-x-3 pt-4">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="flex-1 px-4 py-2 bg-gradient-to-r from-orange-500 to-orange-600 text-white rounded-lg hover:from-orange-600 hover:to-orange-700 transition-all"
            >
              Criar Meta
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
