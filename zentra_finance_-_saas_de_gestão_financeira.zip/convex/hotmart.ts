import { internalMutation, internalQuery } from "./_generated/server";
import { v } from "convex/values";

// Processar compra do Hotmart
export const processPurchase = internalMutation({
  args: {
    transactionId: v.string(),
    buyerEmail: v.string(),
    buyerName: v.string(),
    productId: v.string(),
    productName: v.string(),
    amount: v.number(),
    currency: v.string(),
    status: v.string(),
  },
  handler: async (ctx, args) => {
    // Buscar usuário pelo email
    const user = await ctx.db
      .query("users")
      .withIndex("email", (q) => q.eq("email", args.buyerEmail))
      .unique();

    if (!user) {
      // Criar novo usuário se não existir
      const newUserId = await ctx.db.insert("users", {
        email: args.buyerEmail,
        name: args.buyerName,
        emailVerificationTime: Date.now(),
      });

      // Criar perfil do usuário
      await ctx.db.insert("userProfiles", {
        userId: newUserId,
        firstName: args.buyerName.split(" ")[0] || "",
        lastName: args.buyerName.split(" ").slice(1).join(" ") || "",
        subscriptionStatus: getSubscriptionStatus(args.productId),
        subscriptionExpiry: getSubscriptionExpiry(args.productId),
        hotmartTransactionId: args.transactionId,
        currency: args.currency,
        timezone: "America/Sao_Paulo",
        whatsappConnected: false,
      });

      return { success: true, userId: newUserId, action: "created" };
    } else {
      // Atualizar perfil existente
      const profile = await ctx.db
        .query("userProfiles")
        .withIndex("by_user", (q) => q.eq("userId", user._id))
        .unique();

      if (profile) {
        await ctx.db.patch(profile._id, {
          subscriptionStatus: getSubscriptionStatus(args.productId),
          subscriptionExpiry: getSubscriptionExpiry(args.productId),
          hotmartTransactionId: args.transactionId,
        });
      } else {
        // Criar perfil se não existir
        await ctx.db.insert("userProfiles", {
          userId: user._id,
          firstName: args.buyerName.split(" ")[0] || "",
          lastName: args.buyerName.split(" ").slice(1).join(" ") || "",
          subscriptionStatus: getSubscriptionStatus(args.productId),
          subscriptionExpiry: getSubscriptionExpiry(args.productId),
          hotmartTransactionId: args.transactionId,
          currency: args.currency,
          timezone: "America/Sao_Paulo",
          whatsappConnected: false,
        });
      }

      return { success: true, userId: user._id, action: "updated" };
    }
  },
});

// Cancelar assinatura
export const cancelSubscription = internalMutation({
  args: {
    transactionId: v.string(),
    buyerEmail: v.string(),
  },
  handler: async (ctx, args) => {
    const profile = await ctx.db
      .query("userProfiles")
      .withIndex("by_hotmart_transaction", (q) => q.eq("hotmartTransactionId", args.transactionId))
      .unique();

    if (profile) {
      await ctx.db.patch(profile._id, {
        subscriptionStatus: "free",
        subscriptionExpiry: undefined,
      });

      return { success: true };
    }

    return { success: false, error: "Perfil não encontrado" };
  },
});

// Processar reembolso
export const refundPurchase = internalMutation({
  args: {
    transactionId: v.string(),
    buyerEmail: v.string(),
  },
  handler: async (ctx, args) => {
    const profile = await ctx.db
      .query("userProfiles")
      .withIndex("by_hotmart_transaction", (q) => q.eq("hotmartTransactionId", args.transactionId))
      .unique();

    if (profile) {
      await ctx.db.patch(profile._id, {
        subscriptionStatus: "free",
        subscriptionExpiry: undefined,
        hotmartTransactionId: undefined,
      });

      return { success: true };
    }

    return { success: false, error: "Perfil não encontrado" };
  },
});



// Funções auxiliares para determinar tipo de assinatura
function getSubscriptionStatus(productId: string): "free" | "premium" | "pro" {
  // Mapear IDs dos produtos Hotmart para tipos de assinatura
  const productMapping: Record<string, "free" | "premium" | "pro"> = {
    "premium_monthly": "premium",
    "premium_yearly": "premium",
    "pro_monthly": "pro",
    "pro_yearly": "pro",
  };

  return productMapping[productId] || "premium";
}

function getSubscriptionExpiry(productId: string): number {
  const now = Date.now();
  const oneMonth = 30 * 24 * 60 * 60 * 1000;
  const oneYear = 365 * 24 * 60 * 60 * 1000;

  if (productId.includes("monthly")) {
    return now + oneMonth;
  } else if (productId.includes("yearly")) {
    return now + oneYear;
  }

  return now + oneMonth; // Padrão: 1 mês
}
