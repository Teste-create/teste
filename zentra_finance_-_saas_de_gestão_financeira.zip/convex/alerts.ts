import { query, mutation } from "./_generated/server";
import { v } from "convex/values";
import { getAuthUserId } from "@convex-dev/auth/server";

// Listar alertas do usuário
export const getUserAlerts = query({
  args: {
    unreadOnly: v.optional(v.boolean()),
    limit: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return [];

    let query = ctx.db
      .query("alerts")
      .withIndex("by_user", (q) => q.eq("userId", userId));

    if (args.unreadOnly) {
      query = query.filter((q) => q.eq(q.field("isRead"), false));
    }

    return await query
      .order("desc")
      .take(args.limit || 50);
  },
});

// Marcar alerta como lido
export const markAlertAsRead = mutation({
  args: {
    alertId: v.id("alerts"),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Usuário não autenticado");

    const alert = await ctx.db.get(args.alertId);
    if (!alert || alert.userId !== userId) {
      throw new Error("Alerta não encontrado");
    }

    await ctx.db.patch(args.alertId, { isRead: true });
    return { success: true };
  },
});

// Marcar todos os alertas como lidos
export const markAllAlertsAsRead = mutation({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Usuário não autenticado");

    const unreadAlerts = await ctx.db
      .query("alerts")
      .withIndex("by_user_and_read", (q) => q.eq("userId", userId).eq("isRead", false))
      .collect();

    for (const alert of unreadAlerts) {
      await ctx.db.patch(alert._id, { isRead: true });
    }

    return { success: true, count: unreadAlerts.length };
  },
});

// Criar alerta personalizado
export const createAlert = mutation({
  args: {
    type: v.union(v.literal("budget_limit"), v.literal("goal_progress"), v.literal("recurring_reminder"), v.literal("unusual_spending")),
    title: v.string(),
    message: v.string(),
    severity: v.union(v.literal("info"), v.literal("warning"), v.literal("critical")),
    relatedTransactionId: v.optional(v.id("transactions")),
    relatedGoalId: v.optional(v.id("goals")),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Usuário não autenticado");

    return await ctx.db.insert("alerts", {
      userId,
      type: args.type,
      title: args.title,
      message: args.message,
      isRead: false,
      severity: args.severity,
      relatedTransactionId: args.relatedTransactionId,
      relatedGoalId: args.relatedGoalId,
    });
  },
});

// Deletar alerta
export const deleteAlert = mutation({
  args: {
    alertId: v.id("alerts"),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Usuário não autenticado");

    const alert = await ctx.db.get(args.alertId);
    if (!alert || alert.userId !== userId) {
      throw new Error("Alerta não encontrado");
    }

    await ctx.db.delete(args.alertId);
    return { success: true };
  },
});
