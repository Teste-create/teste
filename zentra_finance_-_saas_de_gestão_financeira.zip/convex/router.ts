import { httpRouter } from "convex/server";
import { httpAction } from "./_generated/server";
import { internal } from "./_generated/api";

const http = httpRouter();

// Webhook do Hotmart para processar pagamentos
http.route({
  path: "/webhook/hotmart",
  method: "POST",
  handler: httpAction(async (ctx, request) => {
    try {
      const body = await request.json();
      
      // Verificar assinatura do webhook (implementar validação real)
      const signature = request.headers.get("x-hotmart-signature");
      if (!signature) {
        return new Response("Unauthorized", { status: 401 });
      }

      // Processar evento do Hotmart
      const { event, data } = body;

      switch (event) {
        case "PURCHASE_COMPLETE":
          await ctx.runMutation(internal.hotmart.processPurchase, {
            transactionId: data.transaction,
            buyerEmail: data.buyer.email,
            buyerName: data.buyer.name,
            productId: data.product.id,
            productName: data.product.name,
            amount: data.purchase.price.value,
            currency: data.purchase.price.currency_code,
            status: data.purchase.status,
          });
          break;

        case "PURCHASE_CANCELED":
          await ctx.runMutation(internal.hotmart.cancelSubscription, {
            transactionId: data.transaction,
            buyerEmail: data.buyer.email,
          });
          break;

        case "PURCHASE_REFUNDED":
          await ctx.runMutation(internal.hotmart.refundPurchase, {
            transactionId: data.transaction,
            buyerEmail: data.buyer.email,
          });
          break;

        default:
          console.log("Evento não tratado:", event);
      }

      return new Response("OK", { status: 200 });
    } catch (error) {
      console.error("Erro no webhook Hotmart:", error);
      return new Response("Internal Server Error", { status: 500 });
    }
  }),
});

// Webhook do WhatsApp para receber mensagens
http.route({
  path: "/webhook/whatsapp",
  method: "POST",
  handler: httpAction(async (ctx, request) => {
    try {
      const body = await request.json();
      
      // Verificar token do WhatsApp Business API
      const token = request.headers.get("authorization");
      if (!token || !token.includes(process.env.WHATSAPP_VERIFY_TOKEN || "")) {
        return new Response("Unauthorized", { status: 401 });
      }

      // Processar mensagens recebidas
      if (body.entry && body.entry[0].changes) {
        for (const change of body.entry[0].changes) {
          if (change.value.messages) {
            for (const message of change.value.messages) {
              const phoneNumber = message.from;
              const messageId = message.id;

              // Buscar usuário pelo número do WhatsApp
              const userProfile = await ctx.runQuery(internal.whatsapp.getUserByWhatsApp, {
                whatsappNumber: phoneNumber,
              });

              if (!userProfile) {
                // Enviar mensagem de boas-vindas ou instrução para cadastro
                continue;
              }

              // Processar diferentes tipos de mensagem
              if (message.type === "text") {
                await ctx.runAction(internal.whatsapp.processTextMessage, {
                  userId: userProfile.userId,
                  messageId,
                  messageContent: message.text.body,
                  phoneNumber,
                });
              } else if (message.type === "audio") {
                await ctx.runAction(internal.whatsapp.processAudioMessage, {
                  userId: userProfile.userId,
                  messageId,
                  audioUrl: message.audio.id, // URL do áudio
                  phoneNumber,
                });
              }
            }
          }
        }
      }

      return new Response("OK", { status: 200 });
    } catch (error) {
      console.error("Erro no webhook WhatsApp:", error);
      return new Response("Internal Server Error", { status: 500 });
    }
  }),
});

// Verificação do webhook do WhatsApp
http.route({
  path: "/webhook/whatsapp",
  method: "GET",
  handler: httpAction(async (ctx, request) => {
    const url = new URL(request.url);
    const mode = url.searchParams.get("hub.mode");
    const token = url.searchParams.get("hub.verify_token");
    const challenge = url.searchParams.get("hub.challenge");

    if (mode === "subscribe" && token === process.env.WHATSAPP_VERIFY_TOKEN) {
      return new Response(challenge, { status: 200 });
    }

    return new Response("Forbidden", { status: 403 });
  }),
});

export default http;
