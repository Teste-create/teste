import { action, internalAction, internalMutation, internalQuery } from "./_generated/server";
import { v } from "convex/values";
import { internal } from "./_generated/api";

// Placeholder para processar mensagem de texto do WhatsApp
export const processTextMessage = internalAction({
  args: {
    userId: v.id("users"),
    messageId: v.string(),
    messageContent: v.string(),
    phoneNumber: v.string(),
  },
  handler: async (ctx, args): Promise<{ success: boolean; transactionId?: string; reason?: string }> => {
    // Salvar mensagem no log
    await ctx.runMutation(internal.whatsapp.saveWhatsAppMessage, {
      userId: args.userId,
      messageId: args.messageId,
      messageType: "text",
      originalContent: args.messageContent,
      processingStatus: "pending",
    });

    try {
      // PLACEHOLDER: Aqui seria integrada a IA para processar o texto
      // Por exemplo, usando OpenAI GPT para extrair informações financeiras
      const aiResult = await processWithAI(args.messageContent);

      if (aiResult.success && aiResult.amount && aiResult.description && aiResult.type && aiResult.category) {
        // Criar transação automaticamente
        const transactionId: string = await ctx.runMutation(internal.whatsapp.createTransactionFromWhatsApp, {
          userId: args.userId,
          messageId: args.messageId,
          amount: aiResult.amount,
          description: aiResult.description,
          type: aiResult.type,
          categoryName: aiResult.category,
          confidence: aiResult.confidence,
        });

        // Atualizar status da mensagem
        await ctx.runMutation(internal.whatsapp.updateMessageStatus, {
          messageId: args.messageId,
          status: "processed",
          extractedAmount: aiResult.amount,
          extractedCategory: aiResult.category,
          extractedDescription: aiResult.description,
          aiConfidence: aiResult.confidence,
          createdTransactionId: transactionId as any,
        });

        return { success: true, transactionId };
      } else {
        // Marcar para revisão manual
        await ctx.runMutation(internal.whatsapp.updateMessageStatus, {
          messageId: args.messageId,
          status: "manual_review",
          errorMessage: "IA não conseguiu processar a mensagem com confiança suficiente",
        });

        return { success: false, reason: "low_confidence" };
      }
    } catch (error) {
      await ctx.runMutation(internal.whatsapp.updateMessageStatus, {
        messageId: args.messageId,
        status: "failed",
        errorMessage: error instanceof Error ? error.message : "Erro desconhecido",
      });

      return { success: false, reason: "processing_error" };
    }
  },
});

// Placeholder para processar áudio do WhatsApp
export const processAudioMessage = internalAction({
  args: {
    userId: v.id("users"),
    messageId: v.string(),
    audioUrl: v.string(),
    phoneNumber: v.string(),
  },
  handler: async (ctx, args): Promise<{ success: boolean; transactionId?: string; reason?: string; transcription?: string }> => {
    // Salvar mensagem no log
    await ctx.runMutation(internal.whatsapp.saveWhatsAppMessage, {
      userId: args.userId,
      messageId: args.messageId,
      messageType: "audio",
      originalContent: args.audioUrl,
      processingStatus: "pending",
    });

    try {
      // PLACEHOLDER: Aqui seria integrada a IA para transcrever e processar áudio
      // 1. Transcrever áudio usando Whisper ou similar
      const transcription = await transcribeAudio(args.audioUrl);
      
      // 2. Processar texto transcrito
      const aiResult = await processWithAI(transcription);

      if (aiResult.success && aiResult.amount && aiResult.description && aiResult.type && aiResult.category) {
        const transactionId: string = await ctx.runMutation(internal.whatsapp.createTransactionFromWhatsApp, {
          userId: args.userId,
          messageId: args.messageId,
          amount: aiResult.amount,
          description: aiResult.description,
          type: aiResult.type,
          categoryName: aiResult.category,
          confidence: aiResult.confidence,
        });

        await ctx.runMutation(internal.whatsapp.updateMessageStatus, {
          messageId: args.messageId,
          status: "processed",
          processedContent: transcription,
          extractedAmount: aiResult.amount,
          extractedCategory: aiResult.category,
          extractedDescription: aiResult.description,
          aiConfidence: aiResult.confidence,
          createdTransactionId: transactionId as any,
        });

        return { success: true, transactionId, transcription };
      } else {
        await ctx.runMutation(internal.whatsapp.updateMessageStatus, {
          messageId: args.messageId,
          status: "manual_review",
          processedContent: transcription,
          errorMessage: "IA não conseguiu processar o áudio com confiança suficiente",
        });

        return { success: false, reason: "low_confidence", transcription };
      }
    } catch (error) {
      await ctx.runMutation(internal.whatsapp.updateMessageStatus, {
        messageId: args.messageId,
        status: "failed",
        errorMessage: error instanceof Error ? error.message : "Erro ao processar áudio",
      });

      return { success: false, reason: "processing_error" };
    }
  },
});

// Salvar mensagem do WhatsApp no log
export const saveWhatsAppMessage = internalMutation({
  args: {
    userId: v.id("users"),
    messageId: v.string(),
    messageType: v.union(v.literal("text"), v.literal("audio"), v.literal("image")),
    originalContent: v.string(),
    processingStatus: v.union(v.literal("pending"), v.literal("processed"), v.literal("failed"), v.literal("manual_review")),
  },
  handler: async (ctx, args) => {
    return await ctx.db.insert("whatsappMessages", {
      userId: args.userId,
      messageId: args.messageId,
      messageType: args.messageType,
      originalContent: args.originalContent,
      processingStatus: args.processingStatus,
    });
  },
});

// Atualizar status da mensagem
export const updateMessageStatus = internalMutation({
  args: {
    messageId: v.string(),
    status: v.union(v.literal("pending"), v.literal("processed"), v.literal("failed"), v.literal("manual_review")),
    processedContent: v.optional(v.string()),
    extractedAmount: v.optional(v.number()),
    extractedCategory: v.optional(v.string()),
    extractedDescription: v.optional(v.string()),
    aiConfidence: v.optional(v.number()),
    createdTransactionId: v.optional(v.id("transactions")),
    errorMessage: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const message = await ctx.db
      .query("whatsappMessages")
      .withIndex("by_message_id", (q) => q.eq("messageId", args.messageId))
      .unique();

    if (!message) throw new Error("Mensagem não encontrada");

    const updates: any = { processingStatus: args.status };
    if (args.processedContent !== undefined) updates.processedContent = args.processedContent;
    if (args.extractedAmount !== undefined) updates.extractedAmount = args.extractedAmount;
    if (args.extractedCategory !== undefined) updates.extractedCategory = args.extractedCategory;
    if (args.extractedDescription !== undefined) updates.extractedDescription = args.extractedDescription;
    if (args.aiConfidence !== undefined) updates.aiConfidence = args.aiConfidence;
    if (args.createdTransactionId !== undefined) updates.createdTransactionId = args.createdTransactionId;
    if (args.errorMessage !== undefined) updates.errorMessage = args.errorMessage;

    await ctx.db.patch(message._id, updates);
    return { success: true };
  },
});

// Criar transação a partir do WhatsApp
export const createTransactionFromWhatsApp = internalMutation({
  args: {
    userId: v.id("users"),
    messageId: v.string(),
    amount: v.number(),
    description: v.string(),
    type: v.union(v.literal("expense"), v.literal("income"), v.literal("investment")),
    categoryName: v.string(),
    confidence: v.number(),
  },
  handler: async (ctx, args) => {
    // Buscar categoria por nome ou usar "Outros"
    let category = await ctx.db
      .query("categories")
      .filter((q) => 
        q.and(
          q.eq(q.field("name"), args.categoryName),
          q.eq(q.field("type"), args.type)
        )
      )
      .first();

    // Se não encontrar, usar categoria "Outros" do tipo correspondente
    if (!category) {
      category = await ctx.db
        .query("categories")
        .filter((q) => 
          q.and(
            q.eq(q.field("name"), "Outros"),
            q.eq(q.field("type"), args.type),
            q.eq(q.field("isDefault"), true)
          )
        )
        .first();
    }

    if (!category) throw new Error("Categoria não encontrada");

    return await ctx.db.insert("transactions", {
      userId: args.userId,
      categoryId: category._id,
      amount: args.amount,
      description: args.description,
      type: args.type,
      date: Date.now(),
      source: "whatsapp",
      isRecurring: false,
      whatsappMessageId: args.messageId,
      aiProcessed: true,
      aiConfidence: args.confidence,
    });
  },
});

// PLACEHOLDER: Função para processar com IA
async function processWithAI(text: string) {
  // PLACEHOLDER: Aqui seria integrada a IA real (OpenAI, Claude, etc.)
  // Por enquanto, retorna um exemplo simulado
  
  // Simular processamento de IA
  await new Promise(resolve => setTimeout(resolve, 1000));

  // Exemplo de detecção simples por palavras-chave
  const lowerText = text.toLowerCase();
  
  if (lowerText.includes("gastei") || lowerText.includes("paguei") || lowerText.includes("comprei")) {
    const amountMatch = text.match(/\d+[,.]?\d*/);
    const amount = amountMatch ? parseFloat(amountMatch[0].replace(",", ".")) : 0;
    
    let category = "Outros";
    if (lowerText.includes("comida") || lowerText.includes("almoço") || lowerText.includes("jantar")) {
      category = "Alimentação";
    } else if (lowerText.includes("uber") || lowerText.includes("gasolina") || lowerText.includes("ônibus")) {
      category = "Transporte";
    }

    return {
      success: amount > 0,
      amount: amount,
      description: text,
      type: "expense" as const,
      category: category,
      confidence: 0.8,
    };
  }

  if (lowerText.includes("recebi") || lowerText.includes("salário") || lowerText.includes("pagamento")) {
    const amountMatch = text.match(/\d+[,.]?\d*/);
    const amount = amountMatch ? parseFloat(amountMatch[0].replace(",", ".")) : 0;
    
    return {
      success: amount > 0,
      amount: amount,
      description: text,
      type: "income" as const,
      category: "Outros",
      confidence: 0.8,
    };
  }

  return {
    success: false,
    amount: 0,
    description: "",
    type: "expense" as const,
    category: "",
    confidence: 0.3,
  };
}

// Buscar usuário por WhatsApp
export const getUserByWhatsApp = internalQuery({
  args: {
    whatsappNumber: v.string(),
  },
  handler: async (ctx, args) => {
    return await ctx.db
      .query("userProfiles")
      .withIndex("by_whatsapp", (q) => q.eq("whatsappNumber", args.whatsappNumber))
      .unique();
  },
});

// PLACEHOLDER: Função para transcrever áudio
async function transcribeAudio(audioUrl: string): Promise<string> {
  // PLACEHOLDER: Aqui seria integrada a API de transcrição (Whisper, Google Speech-to-Text, etc.)
  // Por enquanto, retorna um exemplo
  await new Promise(resolve => setTimeout(resolve, 2000));
  return "Gastei 25 reais no almoço hoje";
}
