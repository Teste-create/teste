import { query, mutation } from "./_generated/server";
import { v } from "convex/values";
import { getAuthUserId } from "@convex-dev/auth/server";

// Listar transações do usuário
export const getUserTransactions = query({
  args: {
    limit: v.optional(v.number()),
    type: v.optional(v.union(v.literal("expense"), v.literal("income"), v.literal("investment"))),
    categoryId: v.optional(v.id("categories")),
    startDate: v.optional(v.number()),
    endDate: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return [];

    let query = ctx.db
      .query("transactions")
      .withIndex("by_user_and_date", (q) => q.eq("userId", userId));

    if (args.startDate) {
      query = query.filter((q) => q.gte(q.field("date"), args.startDate!));
    }

    if (args.endDate) {
      query = query.filter((q) => q.lte(q.field("date"), args.endDate!));
    }

    if (args.type) {
      query = query.filter((q) => q.eq(q.field("type"), args.type!));
    }

    if (args.categoryId) {
      query = query.filter((q) => q.eq(q.field("categoryId"), args.categoryId!));
    }

    const transactions = await query
      .order("desc")
      .take(args.limit || 50);

    // Buscar informações das categorias
    const transactionsWithCategories = await Promise.all(
      transactions.map(async (transaction) => {
        const category = await ctx.db.get(transaction.categoryId);
        return {
          ...transaction,
          category,
        };
      })
    );

    return transactionsWithCategories;
  },
});

// Criar nova transação
export const createTransaction = mutation({
  args: {
    categoryId: v.id("categories"),
    amount: v.number(),
    description: v.string(),
    type: v.union(v.literal("expense"), v.literal("income"), v.literal("investment")),
    date: v.optional(v.number()),
    receiptUrl: v.optional(v.id("_storage")),
    location: v.optional(v.string()),
    tags: v.optional(v.array(v.string())),
    isRecurring: v.optional(v.boolean()),
    recurringFrequency: v.optional(v.union(v.literal("daily"), v.literal("weekly"), v.literal("monthly"), v.literal("yearly"))),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Usuário não autenticado");

    const transactionId = await ctx.db.insert("transactions", {
      userId,
      categoryId: args.categoryId,
      amount: args.amount,
      description: args.description,
      type: args.type,
      date: args.date || Date.now(),
      source: "manual",
      receiptUrl: args.receiptUrl,
      location: args.location,
      tags: args.tags,
      isRecurring: args.isRecurring || false,
      recurringFrequency: args.recurringFrequency,
      aiProcessed: false,
    });

    // Atualizar orçamento se for despesa
    if (args.type === "expense") {
      await updateBudgetSpending(ctx, userId, args.categoryId, args.amount);
    }

    return transactionId;
  },
});

// Atualizar transação
export const updateTransaction = mutation({
  args: {
    transactionId: v.id("transactions"),
    categoryId: v.optional(v.id("categories")),
    amount: v.optional(v.number()),
    description: v.optional(v.string()),
    date: v.optional(v.number()),
    receiptUrl: v.optional(v.id("_storage")),
    location: v.optional(v.string()),
    tags: v.optional(v.array(v.string())),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Usuário não autenticado");

    const transaction = await ctx.db.get(args.transactionId);
    if (!transaction || transaction.userId !== userId) {
      throw new Error("Transação não encontrada");
    }

    const updates: any = {};
    if (args.categoryId !== undefined) updates.categoryId = args.categoryId;
    if (args.amount !== undefined) updates.amount = args.amount;
    if (args.description !== undefined) updates.description = args.description;
    if (args.date !== undefined) updates.date = args.date;
    if (args.receiptUrl !== undefined) updates.receiptUrl = args.receiptUrl;
    if (args.location !== undefined) updates.location = args.location;
    if (args.tags !== undefined) updates.tags = args.tags;

    await ctx.db.patch(args.transactionId, updates);

    return { success: true };
  },
});

// Deletar transação
export const deleteTransaction = mutation({
  args: {
    transactionId: v.id("transactions"),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Usuário não autenticado");

    const transaction = await ctx.db.get(args.transactionId);
    if (!transaction || transaction.userId !== userId) {
      throw new Error("Transação não encontrada");
    }

    await ctx.db.delete(args.transactionId);
    return { success: true };
  },
});

// Obter resumo financeiro por período
export const getFinancialSummary = query({
  args: {
    startDate: v.number(),
    endDate: v.number(),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return null;

    const transactions = await ctx.db
      .query("transactions")
      .withIndex("by_user_and_date", (q) => 
        q.eq("userId", userId)
         .gte("date", args.startDate)
         .lte("date", args.endDate)
      )
      .collect();

    const summary = {
      totalIncome: 0,
      totalExpenses: 0,
      totalInvestments: 0,
      balance: 0,
      transactionCount: transactions.length,
      expensesByCategory: {} as Record<string, number>,
      incomeByCategory: {} as Record<string, number>,
      investmentsByCategory: {} as Record<string, number>,
    };

    for (const transaction of transactions) {
      const category = await ctx.db.get(transaction.categoryId);
      const categoryName = category?.name || "Outros";

      switch (transaction.type) {
        case "income":
          summary.totalIncome += transaction.amount;
          summary.incomeByCategory[categoryName] = 
            (summary.incomeByCategory[categoryName] || 0) + transaction.amount;
          break;
        case "expense":
          summary.totalExpenses += transaction.amount;
          summary.expensesByCategory[categoryName] = 
            (summary.expensesByCategory[categoryName] || 0) + transaction.amount;
          break;
        case "investment":
          summary.totalInvestments += transaction.amount;
          summary.investmentsByCategory[categoryName] = 
            (summary.investmentsByCategory[categoryName] || 0) + transaction.amount;
          break;
      }
    }

    summary.balance = summary.totalIncome - summary.totalExpenses - summary.totalInvestments;

    return summary;
  },
});

// Função auxiliar para atualizar gastos do orçamento
async function updateBudgetSpending(ctx: any, userId: string, categoryId: string, amount: number) {
  const now = new Date();
  const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1).getTime();

  const budget = await ctx.db
    .query("budgets")
    .withIndex("by_user_and_category", (q: any) => 
      q.eq("userId", userId).eq("categoryId", categoryId)
    )
    .filter((q: any) => q.eq(q.field("month"), startOfMonth))
    .unique();

  if (budget) {
    await ctx.db.patch(budget._id, {
      currentSpent: budget.currentSpent + amount,
    });

    // Verificar se precisa criar alerta
    const spentPercentage = (budget.currentSpent + amount) / budget.monthlyLimit;
    if (spentPercentage >= budget.alertThreshold) {
      await ctx.db.insert("alerts", {
        userId,
        type: "budget_limit",
        title: "Limite de orçamento atingido",
        message: `Você atingiu ${Math.round(spentPercentage * 100)}% do seu orçamento mensal para esta categoria.`,
        isRead: false,
        severity: spentPercentage >= 1 ? "critical" : "warning",
        categoryId,
        triggerAmount: amount,
      });
    }
  }
}
