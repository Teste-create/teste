import { query, mutation } from "./_generated/server";
import { v } from "convex/values";
import { getAuthUserId } from "@convex-dev/auth/server";

// Listar feedback do usuário
export const getUserFeedback = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return [];

    return await ctx.db
      .query("feedback")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .order("desc")
      .collect();
  },
});

// Criar novo feedback
export const createFeedback = mutation({
  args: {
    type: v.union(v.literal("bug"), v.literal("feature_request"), v.literal("improvement"), v.literal("general")),
    title: v.string(),
    description: v.string(),
    priority: v.optional(v.union(v.literal("low"), v.literal("medium"), v.literal("high"))),
    attachmentUrl: v.optional(v.id("_storage")),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Usuário não autenticado");

    return await ctx.db.insert("feedback", {
      userId,
      type: args.type,
      title: args.title,
      description: args.description,
      priority: args.priority || "medium",
      status: "open",
      attachmentUrl: args.attachmentUrl,
    });
  },
});

// Gerar URL de upload para anexo
export const generateUploadUrl = mutation({
  args: {},
  handler: async (ctx) => {
    return await ctx.storage.generateUploadUrl();
  },
});
