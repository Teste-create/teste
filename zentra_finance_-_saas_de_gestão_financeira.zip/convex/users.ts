import { query, mutation } from "./_generated/server";
import { v } from "convex/values";
import { getAuthUserId } from "@convex-dev/auth/server";

// Obter perfil do usuário logado
export const getCurrentUserProfile = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return null;

    const user = await ctx.db.get(userId);
    if (!user) return null;

    const profile = await ctx.db
      .query("userProfiles")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .unique();

    return {
      user,
      profile,
    };
  },
});

// Criar ou atualizar perfil do usuário
export const createOrUpdateProfile = mutation({
  args: {
    firstName: v.string(),
    lastName: v.string(),
    phone: v.optional(v.string()),
    monthlyBudget: v.optional(v.number()),
    currency: v.string(),
    timezone: v.string(),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Usuário não autenticado");

    const existingProfile = await ctx.db
      .query("userProfiles")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .unique();

    if (existingProfile) {
      await ctx.db.patch(existingProfile._id, {
        firstName: args.firstName,
        lastName: args.lastName,
        phone: args.phone,
        monthlyBudget: args.monthlyBudget,
        currency: args.currency,
        timezone: args.timezone,
      });
      return existingProfile._id;
    } else {
      return await ctx.db.insert("userProfiles", {
        userId,
        firstName: args.firstName,
        lastName: args.lastName,
        phone: args.phone,
        subscriptionStatus: "free",
        monthlyBudget: args.monthlyBudget,
        currency: args.currency,
        timezone: args.timezone,
        whatsappConnected: false,
      });
    }
  },
});

// Conectar WhatsApp
export const connectWhatsApp = mutation({
  args: {
    whatsappNumber: v.string(),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Usuário não autenticado");

    const profile = await ctx.db
      .query("userProfiles")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .unique();

    if (!profile) throw new Error("Perfil não encontrado");

    await ctx.db.patch(profile._id, {
      whatsappConnected: true,
      whatsappNumber: args.whatsappNumber,
    });

    return { success: true };
  },
});

// Obter estatísticas do usuário
export const getUserStats = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return null;

    const now = new Date();
    const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1).getTime();
    const startOfWeek = new Date(now.setDate(now.getDate() - now.getDay())).getTime();

    // Transações do mês atual
    const monthlyTransactions = await ctx.db
      .query("transactions")
      .withIndex("by_user_and_date", (q) => 
        q.eq("userId", userId).gte("date", startOfMonth)
      )
      .collect();

    // Transações da semana atual
    const weeklyTransactions = await ctx.db
      .query("transactions")
      .withIndex("by_user_and_date", (q) => 
        q.eq("userId", userId).gte("date", startOfWeek)
      )
      .collect();

    const monthlyExpenses = monthlyTransactions
      .filter(t => t.type === "expense")
      .reduce((sum, t) => sum + t.amount, 0);

    const monthlyIncome = monthlyTransactions
      .filter(t => t.type === "income")
      .reduce((sum, t) => sum + t.amount, 0);

    const monthlyInvestments = monthlyTransactions
      .filter(t => t.type === "investment")
      .reduce((sum, t) => sum + t.amount, 0);

    const weeklyExpenses = weeklyTransactions
      .filter(t => t.type === "expense")
      .reduce((sum, t) => sum + t.amount, 0);

    return {
      monthly: {
        expenses: monthlyExpenses,
        income: monthlyIncome,
        investments: monthlyInvestments,
        balance: monthlyIncome - monthlyExpenses - monthlyInvestments,
        transactionCount: monthlyTransactions.length,
      },
      weekly: {
        expenses: weeklyExpenses,
        transactionCount: weeklyTransactions.length,
      },
    };
  },
});
