import { query, mutation } from "./_generated/server";
import { v } from "convex/values";
import { getAuthUserId } from "@convex-dev/auth/server";

// Listar metas do usuário
export const getUserGoals = query({
  args: {
    status: v.optional(v.union(v.literal("active"), v.literal("completed"), v.literal("paused"))),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return [];

    let query = ctx.db
      .query("goals")
      .withIndex("by_user", (q) => q.eq("userId", userId));

    if (args.status) {
      query = query.filter((q) => q.eq(q.field("status"), args.status));
    }

    return await query.order("desc").collect();
  },
});

// Criar nova meta
export const createGoal = mutation({
  args: {
    title: v.string(),
    description: v.optional(v.string()),
    targetAmount: v.number(),
    targetDate: v.number(),
    category: v.union(v.literal("savings"), v.literal("expense_limit"), v.literal("investment"), v.literal("debt_payoff")),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Usuário não autenticado");

    return await ctx.db.insert("goals", {
      userId,
      title: args.title,
      description: args.description,
      targetAmount: args.targetAmount,
      currentAmount: 0,
      targetDate: args.targetDate,
      category: args.category,
      status: "active",
      isActive: true,
    });
  },
});

// Atualizar progresso da meta
export const updateGoalProgress = mutation({
  args: {
    goalId: v.id("goals"),
    amount: v.number(),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Usuário não autenticado");

    const goal = await ctx.db.get(args.goalId);
    if (!goal || goal.userId !== userId) {
      throw new Error("Meta não encontrada");
    }

    const newAmount = goal.currentAmount + args.amount;
    const status = newAmount >= goal.targetAmount ? "completed" : goal.status;

    await ctx.db.patch(args.goalId, {
      currentAmount: newAmount,
      status,
    });

    // Criar alerta se meta foi atingida
    if (status === "completed" && goal.status !== "completed") {
      await ctx.db.insert("alerts", {
        userId,
        type: "goal_progress",
        title: "Meta atingida! 🎉",
        message: `Parabéns! Você atingiu sua meta "${goal.title}".`,
        isRead: false,
        severity: "info",
        relatedGoalId: args.goalId,
      });
    }

    return { success: true, completed: status === "completed" };
  },
});

// Atualizar meta
export const updateGoal = mutation({
  args: {
    goalId: v.id("goals"),
    title: v.optional(v.string()),
    description: v.optional(v.string()),
    targetAmount: v.optional(v.number()),
    targetDate: v.optional(v.number()),
    status: v.optional(v.union(v.literal("active"), v.literal("completed"), v.literal("paused"))),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Usuário não autenticado");

    const goal = await ctx.db.get(args.goalId);
    if (!goal || goal.userId !== userId) {
      throw new Error("Meta não encontrada");
    }

    const updates: any = {};
    if (args.title !== undefined) updates.title = args.title;
    if (args.description !== undefined) updates.description = args.description;
    if (args.targetAmount !== undefined) updates.targetAmount = args.targetAmount;
    if (args.targetDate !== undefined) updates.targetDate = args.targetDate;
    if (args.status !== undefined) {
      updates.status = args.status;
      updates.isActive = args.status === "active";
    }

    await ctx.db.patch(args.goalId, updates);
    return { success: true };
  },
});

// Deletar meta
export const deleteGoal = mutation({
  args: {
    goalId: v.id("goals"),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Usuário não autenticado");

    const goal = await ctx.db.get(args.goalId);
    if (!goal || goal.userId !== userId) {
      throw new Error("Meta não encontrada");
    }

    await ctx.db.delete(args.goalId);
    return { success: true };
  },
});
