import { query, mutation } from "./_generated/server";
import { v } from "convex/values";
import { getAuthUserId } from "@convex-dev/auth/server";

// Obter todas as categorias (padrão + personalizadas do usuário)
export const getAllCategories = query({
  args: {
    type: v.optional(v.union(v.literal("expense"), v.literal("income"), v.literal("investment"))),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    
    // Categorias padrão do sistema
    const defaultCategories = await ctx.db
      .query("categories")
      .withIndex("by_type", (q) => 
        args.type ? q.eq("type", args.type) : q
      )
      .filter((q) => q.eq(q.field("isDefault"), true))
      .collect();

    // Categorias personalizadas do usuário
    let userCategories: any[] = [];
    if (userId) {
      userCategories = await ctx.db
        .query("categories")
        .withIndex("by_user_and_type", (q) => 
          args.type 
            ? q.eq("userId", userId).eq("type", args.type)
            : q.eq("userId", userId)
        )
        .collect();
    }

    return [...defaultCategories, ...userCategories];
  },
});

// Criar categoria personalizada
export const createCategory = mutation({
  args: {
    name: v.string(),
    type: v.union(v.literal("expense"), v.literal("income"), v.literal("investment")),
    icon: v.string(),
    color: v.string(),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Usuário não autenticado");

    return await ctx.db.insert("categories", {
      name: args.name,
      type: args.type,
      icon: args.icon,
      color: args.color,
      isDefault: false,
      userId,
    });
  },
});

// Inicializar categorias padrão (executar uma vez)
export const initializeDefaultCategories = mutation({
  args: {},
  handler: async (ctx) => {
    const existingCategories = await ctx.db
      .query("categories")
      .filter((q) => q.eq(q.field("isDefault"), true))
      .collect();

    if (existingCategories.length > 0) {
      return { message: "Categorias padrão já existem" };
    }

    const defaultCategories = [
      // Despesas
      { name: "Alimentação", type: "expense", icon: "🍽️", color: "#FF6B35" },
      { name: "Transporte", type: "expense", icon: "🚗", color: "#4ECDC4" },
      { name: "Saúde", type: "expense", icon: "🏥", color: "#45B7D1" },
      { name: "Lazer", type: "expense", icon: "🎮", color: "#96CEB4" },
      { name: "Educação", type: "expense", icon: "📚", color: "#FFEAA7" },
      { name: "Casa", type: "expense", icon: "🏠", color: "#DDA0DD" },
      { name: "Roupas", type: "expense", icon: "👕", color: "#98D8C8" },
      { name: "Outros", type: "expense", icon: "📦", color: "#A0A0A0" },

      // Receitas
      { name: "Salário", type: "income", icon: "💰", color: "#00B894" },
      { name: "Freelance", type: "income", icon: "💻", color: "#6C5CE7" },
      { name: "Vendas", type: "income", icon: "🛒", color: "#FD79A8" },
      { name: "Rendimentos", type: "income", icon: "📈", color: "#FDCB6E" },
      { name: "Outros", type: "income", icon: "💵", color: "#74B9FF" },

      // Investimentos
      { name: "Ações", type: "investment", icon: "📊", color: "#E17055" },
      { name: "Fundos", type: "investment", icon: "🏦", color: "#0984E3" },
      { name: "Poupança", type: "investment", icon: "🐷", color: "#00B894" },
      { name: "Criptomoedas", type: "investment", icon: "₿", color: "#FDCB6E" },
      { name: "Imóveis", type: "investment", icon: "🏢", color: "#6C5CE7" },
    ];

    for (const category of defaultCategories) {
      await ctx.db.insert("categories", {
        ...category,
        type: category.type as "expense" | "income" | "investment",
        isDefault: true,
        userId: undefined,
      });
    }

    return { message: "Categorias padrão criadas com sucesso" };
  },
});
