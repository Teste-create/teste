import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";
import { authTables } from "@convex-dev/auth/server";

const applicationTables = {
  // Perfil do usuário com dados de assinatura
  userProfiles: defineTable({
    userId: v.id("users"),
    firstName: v.string(),
    lastName: v.string(),
    phone: v.optional(v.string()),
    subscriptionStatus: v.union(v.literal("free"), v.literal("premium"), v.literal("pro")),
    subscriptionExpiry: v.optional(v.number()),
    hotmartTransactionId: v.optional(v.string()),
    monthlyBudget: v.optional(v.number()),
    currency: v.string(), // BRL, USD, EUR
    timezone: v.string(),
    whatsappConnected: v.boolean(),
    whatsappNumber: v.optional(v.string()),
  })
    .index("by_user", ["userId"])
    .index("by_hotmart_transaction", ["hotmartTransactionId"])
    .index("by_whatsapp", ["whatsappNumber"]),

  // Categorias de transações
  categories: defineTable({
    name: v.string(),
    type: v.union(v.literal("expense"), v.literal("income"), v.literal("investment")),
    icon: v.string(),
    color: v.string(),
    isDefault: v.boolean(),
    userId: v.optional(v.id("users")), // null para categorias padrão do sistema
  })
    .index("by_user_and_type", ["userId", "type"])
    .index("by_type", ["type"]),

  // Transações financeiras
  transactions: defineTable({
    userId: v.id("users"),
    categoryId: v.id("categories"),
    amount: v.number(),
    description: v.string(),
    type: v.union(v.literal("expense"), v.literal("income"), v.literal("investment")),
    date: v.number(),
    source: v.union(v.literal("manual"), v.literal("whatsapp"), v.literal("upload")),
    receiptUrl: v.optional(v.id("_storage")),
    location: v.optional(v.string()),
    tags: v.optional(v.array(v.string())),
    isRecurring: v.boolean(),
    recurringFrequency: v.optional(v.union(v.literal("daily"), v.literal("weekly"), v.literal("monthly"), v.literal("yearly"))),
    whatsappMessageId: v.optional(v.string()),
    aiProcessed: v.boolean(),
    aiConfidence: v.optional(v.number()),
  })
    .index("by_user_and_date", ["userId", "date"])
    .index("by_user_and_category", ["userId", "categoryId"])
    .index("by_user_and_type", ["userId", "type"])
    .index("by_whatsapp_message", ["whatsappMessageId"]),

  // Metas financeiras
  goals: defineTable({
    userId: v.id("users"),
    title: v.string(),
    description: v.optional(v.string()),
    targetAmount: v.number(),
    currentAmount: v.number(),
    targetDate: v.number(),
    category: v.union(v.literal("savings"), v.literal("expense_limit"), v.literal("investment"), v.literal("debt_payoff")),
    status: v.union(v.literal("active"), v.literal("completed"), v.literal("paused")),
    isActive: v.boolean(),
  })
    .index("by_user", ["userId"])
    .index("by_user_and_status", ["userId", "status"]),

  // Alertas e notificações
  alerts: defineTable({
    userId: v.id("users"),
    type: v.union(v.literal("budget_limit"), v.literal("goal_progress"), v.literal("recurring_reminder"), v.literal("unusual_spending")),
    title: v.string(),
    message: v.string(),
    isRead: v.boolean(),
    severity: v.union(v.literal("info"), v.literal("warning"), v.literal("critical")),
    relatedTransactionId: v.optional(v.id("transactions")),
    relatedGoalId: v.optional(v.id("goals")),
    triggerAmount: v.optional(v.number()),
    categoryId: v.optional(v.id("categories")),
  })
    .index("by_user", ["userId"])
    .index("by_user_and_read", ["userId", "isRead"]),

  // Orçamentos por categoria
  budgets: defineTable({
    userId: v.id("users"),
    categoryId: v.id("categories"),
    monthlyLimit: v.number(),
    currentSpent: v.number(),
    month: v.number(), // timestamp do primeiro dia do mês
    alertThreshold: v.number(), // porcentagem (0.8 = 80%)
    isActive: v.boolean(),
  })
    .index("by_user_and_month", ["userId", "month"])
    .index("by_user_and_category", ["userId", "categoryId"]),

  // Feedback e sugestões dos usuários
  feedback: defineTable({
    userId: v.id("users"),
    type: v.union(v.literal("bug"), v.literal("feature_request"), v.literal("improvement"), v.literal("general")),
    title: v.string(),
    description: v.string(),
    priority: v.union(v.literal("low"), v.literal("medium"), v.literal("high")),
    status: v.union(v.literal("open"), v.literal("in_progress"), v.literal("resolved"), v.literal("closed")),
    attachmentUrl: v.optional(v.id("_storage")),
  })
    .index("by_user", ["userId"])
    .index("by_status", ["status"]),

  // Log de processamento de mensagens WhatsApp
  whatsappMessages: defineTable({
    userId: v.id("users"),
    messageId: v.string(),
    messageType: v.union(v.literal("text"), v.literal("audio"), v.literal("image")),
    originalContent: v.string(),
    processedContent: v.optional(v.string()),
    extractedAmount: v.optional(v.number()),
    extractedCategory: v.optional(v.string()),
    extractedDescription: v.optional(v.string()),
    aiConfidence: v.optional(v.number()),
    processingStatus: v.union(v.literal("pending"), v.literal("processed"), v.literal("failed"), v.literal("manual_review")),
    createdTransactionId: v.optional(v.id("transactions")),
    errorMessage: v.optional(v.string()),
  })
    .index("by_user", ["userId"])
    .index("by_message_id", ["messageId"])
    .index("by_status", ["processingStatus"]),
};

export default defineSchema({
  ...authTables,
  ...applicationTables,
});
